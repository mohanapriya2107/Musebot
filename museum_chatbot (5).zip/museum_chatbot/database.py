import mysql.connector
from mysql.connector import Error
import requests
from datetime import datetime,timedelta
import calendar
import sqlite3
import re

API_KEY = 'yi8U3ni7qxsREArm1ME1ZyMr9lU5liRl'

def get_public_holidays_for_india(year=datetime.now().year):
    url = f"https://calendarific.com/api/v2/holidays"
    
    params = {
        "api_key": API_KEY,
        "country": "IN",  # Country code for India
        "year": year      # Year for which you want to fetch the holidays
    }

    try:
        response = requests.get(url, params=params)
        data = response.json()

        # Check if the request was successful
        if response.status_code == 200 and data.get("meta", {}).get("code") == 200:
            holidays = data.get("response", {}).get("holidays", [])
            holiday_dates = [holiday["date"]["iso"] for holiday in holidays]
            return holiday_dates
        else:
            print("Error fetching holidays:", data.get("meta", {}).get("error_detail"))
            return []
    except Exception as e:
        print(f"Error fetching public holidays: {e}")
        return []

def is_public_holiday(booking_date):
    # Get the list of public holidays for the current year
    public_holidays = get_public_holidays_for_india()
    print(public_holidays)

    # Check if the entered date is in the public holidays list
    if booking_date in public_holidays:
        return True
    return False

def create_connection():
    """Create and return a connection to the MySQL database."""
    try:
        connection = mysql.connector.connect(
            host='localhost',  # Replace with your MySQL host
            user='root',  # Replace with your MySQL username
            password='Mohana@04',  # Replace with your MySQL password
            database='museum'  # Your database name
        )
        if connection.is_connected():
            return connection
    except Error as e:
        print(f"Error: {e}")
    return None

def fetch_museum_data_by_name_with_prices(museum_name, user_type):
    connection = create_connection()
    if connection:
        cursor = connection.cursor(dictionary=True)
        
        # Ensure that museum_name and user_type are properly formatted
        museum_name = museum_name.strip()
        
        query = """
            SELECT m.name, m.location, m.opening_hours, m.holidays, m.description,
                   tp.adult_price, tp.children_price, tp.photography_fee, tp.student_fee
            FROM museums m
            JOIN ticket_price tp ON tp.museum_id = m.id
            WHERE m.name = %s AND tp.type = %s
        """
        print(f"Query: {query}")
        print(f"Parameters: {museum_name}, {user_type}")
        
        try:
            cursor.execute(query, (museum_name, user_type))
            result = cursor.fetchone()
            print(f"Fetched data: {result}")  # Debugging line
            
            if result:
                museum_details = {
                    'name': result['name'],
                    'location': result['location'],
                    'opening_hours': result['opening_hours'],
                    'holidays': result['holidays'],
                    'description': result['description'],
                    'prices': {
                        'Adult': result['adult_price'],
                        'Children': result['children_price'],
                        'Photography Fee': result['photography_fee'],
                        'Student': result['student_fee']
                    }
                }
                # Fetch all remaining results to clear the cursor
                cursor.fetchall()
                return museum_details
            else:
                return None
        except Error as e:
            print(f"Error: {e}")
            return None
        finally:
            cursor.close()
            connection.close()

def fetch_museum_data_by_category(category):
    """
    Fetch museums by category.
    Args:
        category (str): Museum category (e.g., Arts, History).
    Returns:
        list: A list of museums in the category.
    """
    connection = create_connection()
    if connection:
        cursor = connection.cursor(dictionary=True)
        query = "SELECT name, location FROM museums WHERE category = %s"
        try:
            cursor.execute(query, (category,))
            museums = cursor.fetchall()
            return museums
        except Error as e:
            print(f"Error fetching museums by category: {e}")
            return []
        finally:
            cursor.close()
            connection.close()
    return []

def fetch_ticket_prices_by_type(museum_name, user_type):
    """
    Fetch ticket prices for a museum and user type.
    Args:
        museum_name (str): Name of the museum.
        user_type (str): Type of user (e.g., Indian/Foreigner).
    Returns:
        dict: Ticket price details.
    """
    connection = create_connection()
    if connection:
        cursor = connection.cursor(dictionary=True)
        query = """
            SELECT tp.adult_price, tp.children_price, tp.photography_fee, tp.student_fee
            FROM ticket_price tp
            JOIN museums m ON tp.museum_id = m.id
            WHERE m.name = %s AND tp.type = %s
        """
        try:
            cursor.execute(query, (museum_name, user_type))
            ticket_prices = cursor.fetchone()
            return ticket_prices
        except Error as e:
            print(f"Error fetching ticket prices: {e}")
            return None
        finally:
            cursor.close()
            connection.close()
    return None

def fetch_museum_data(museum_name):
    connection = create_connection()
    if connection:
        cursor = connection.cursor(dictionary=True)
        query = "SELECT opening_hours, holidays, required_time FROM museums WHERE name = %s"
        try:
            cursor.execute(query, (museum_name,))
            museum_data = cursor.fetchone()
            # Fetch all remaining results to clear the cursor
            cursor.fetchall()
            return museum_data
        except mysql.connector.Error as e:
            print(f"Error fetching museum data: {e}")
            return None
        finally:
            cursor.close()
            connection.close()
    return None

def is_museum_open(museum_name, booking_date, booking_time_str):
    museum_data = fetch_museum_data(museum_name)
    if not museum_data:
        return False, "Museum not found."

    # Fetch and clean the opening hours
    opening_hours = museum_data.get('opening_hours', 'Not available')
    holidays = museum_data.get('holidays', '').split(',')
    required_time_str = museum_data.get('required_time', '0 hours')

    # Extract the time range from the opening hours string
    match = re.search(r'(\d{1,2}:\d{2}\s*[AP]M)\s*to\s*(\d{1,2}:\d{2}\s*[AP]M)', opening_hours)
    if not match:
        return False, "Invalid opening hours format. Please ensure they follow 'HH:MM AM/PM to HH:MM AM/PM'."

    opening_start, opening_end = match.groups()

    day_of_week = calendar.day_name[datetime.strptime(booking_date, "%Y-%m-%d").weekday()]

    if callable(is_public_holiday) and is_public_holiday(booking_date):
        return False, f"The entered date is a public holiday. Please choose another date."

    if day_of_week in holidays:
        return False, f"The museum is closed on {day_of_week}s. Please choose another date."

    try:
        opening_start_time = datetime.strptime(opening_start, "%I:%M %p").time()
        opening_end_time = datetime.strptime(opening_end, "%I:%M %p").time()

        booking_time_obj = datetime.strptime(booking_time_str, "%I:%M %p").time()

        if opening_start_time <= booking_time_obj <= opening_end_time:
            required_time = 0
            match_hours = re.search(r"(\d+)\s*hour", required_time_str.lower())
            match_minutes = re.search(r"(\d+)\s*minute", required_time_str.lower())
            if match_hours:
                required_time += int(match_hours.group(1)) * 60
            if match_minutes:
                required_time += int(match_minutes.group(1))
            required_time_delta = timedelta(minutes=required_time)

            booking_time_obj_dt = datetime.combine(datetime.today(), booking_time_obj)
            closing_time_obj_dt = datetime.combine(datetime.today(), opening_end_time)

            if opening_start_time > opening_end_time:  # Handle overnight opening hours
                closing_time_obj_dt += timedelta(days=1)

            if closing_time_obj_dt - booking_time_obj_dt < required_time_delta:
                return False, f"Please select a time that allows at least {required_time // 60} hours for your visit."

            return True, "The museum is open at the selected time."
        else:
            return False, "The selected time is outside of the museum's opening hours."

    except ValueError as e:
        return False, f"Error parsing time data: {str(e)}"

    
# Test the database functions
if __name__ == "__main__":
    print("Testing database module...")

    # Test fetching museum by category
    print("Museums in the category 'Arts':")
    print(fetch_museum_data_by_category("Arts"))

    # Test fetching museum details by name
    print("\nMuseum details for 'Victoria Memorial':")
    print(fetch_museum_data_by_name_with_prices("Victoria Memorial", "Indian"))

    print(fetch_museum_data("Victoria Memorial"))
    # Test fetching ticket prices
    print("\nTicket prices for 'Victoria Memorial' (Indian):")
    print(fetch_ticket_prices_by_type("Victoria Memorial", "Indian"))