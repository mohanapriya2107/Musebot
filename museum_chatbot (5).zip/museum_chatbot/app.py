from flask import Flask, render_template, request, redirect, url_for, jsonify, flash, session
from database import fetch_museum_data_by_category, fetch_museum_data_by_name_with_prices, fetch_ticket_prices_by_type, fetch_museum_data, is_museum_open
import pickle
import random
from datetime import datetime, timedelta
import sqlite3
import uuid
import joblib
import difflib
from sklearn.metrics.pairwise import cosine_similarity
app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Required for flashing messages

# Load the saved model components
def load_model():
    vectorizer = joblib.load('vectorizer.pkl')
    train_names = joblib.load('train_names.pkl')
    train_vectors = joblib.load('train_vectors.pkl')
    return vectorizer, train_names, train_vectors

# Function to find the best match using cosine similarity and difflib
def find_best_match(query, vectorizer, train_vectors, train_names):
    query_vector = vectorizer.transform([query])
    similarities = cosine_similarity(query_vector, train_vectors)
    best_match_index = similarities.argmax()
    best_match_name = train_names[best_match_index]
    
    # Use difflib to refine the best match
    difflib_scores = [difflib.SequenceMatcher(None, query, name).ratio() for name in train_names]
    best_difflib_match_index = difflib_scores.index(max(difflib_scores))
    best_difflib_match_name = train_names[best_difflib_match_index]
    
    # Combine scores
    combined_scores = [(similarity + difflib_score) / 2 for similarity, difflib_score in zip(similarities[0], difflib_scores)]
    best_combined_match_index = combined_scores.index(max(combined_scores))
    best_combined_match_name = train_names[best_combined_match_index]
    
    return best_combined_match_name

# In-memory storage for bookings (for demonstration purposes)
user_bookings = {}

def create_bookings_table():
    conn = sqlite3.connect('bookings.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS bookings (
            ticket_id TEXT PRIMARY KEY,
            user_name TEXT NOT NULL,
            adult_tickets INTEGER NOT NULL,
            children_tickets INTEGER NOT NULL,
            photography_tickets INTEGER NOT NULL,
            booking_date TEXT NOT NULL,
            booking_time TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

# Function to store booking details in the database
def store_booking_in_db(booking_details):
    conn = sqlite3.connect('bookings.db')
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO bookings (ticket_id, user_name, adult_tickets, children_tickets, photography_tickets, booking_date, booking_time)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (
        booking_details['ticket_id'],
        booking_details['user_name'],
        booking_details['adult_tickets'],
        booking_details['children_tickets'],
        booking_details['photography_tickets'],
        booking_details['booking_date'],
        booking_details['booking_time']
    ))
    conn.commit()
    conn.close()

# Ensure table creation
create_bookings_table()

@app.route('/')
def index():
    """Render the language selection page."""
    return render_template('language.html')

@app.route('/language_selection', methods=['POST'])
def language_selection():
    """Handle language selection and redirect to the main menu."""
    return redirect(url_for('main_menu'))

@app.route('/main_menu', methods=['GET', 'POST'])
def main_menu():
    """Render the main menu with options for ticket booking and booking management."""
    return render_template('main_menu.html')

@app.route('/options', methods=['POST'])
def options():
    """Display options after language selection."""
    return render_template('options.html')

@app.route('/recommend')
def recommend_museums():
    """Display museum categories for recommendation."""
    categories = [
        "Arts", 
        "Historical Museums", 
        "Science and Technology Museums",
        "Museum-house",
        "Archeology Museums", 
        "General Museums"
    ]
    return render_template('recommend.html', categories=categories)

@app.route('/recommend/<category>')
def display_museums_by_category(category):
    """Fetch and display museums by the selected category."""
    museums = fetch_museum_data_by_category(category)
    if museums:
        return render_template('category_museums.html', category=category, museums=museums)
    else:
        return render_template('error.html', message="No museums found in this category.")

@app.route('/museum/<museum_name>')
def display_museum_details(museum_name):
    """Display a form to select user type before showing museum details."""
    return render_template('select_user_type.html', museum_name=museum_name)

@app.route('/museum_details', methods=['POST'])
def show_museum_details():
    """Display details for a selected museum based on user type."""
    museum_name = request.form.get('museum_name')
    user_type = request.form.get('user_type')

    if not museum_name or not user_type:
        return render_template('error.html', message="Please select a user type.")

    museum_details = fetch_museum_data_by_name_with_prices(museum_name, user_type)

    if museum_details:
        return render_template('museum_details.html', museum_details=museum_details)
    else:
        return render_template('error.html', message="Museum details not found.")

@app.route('/search', methods=['GET', 'POST'])
def search():
    if request.method == 'POST':
        query = request.json.get('query')  # Get the search query from the request
        
        if not query:
            return jsonify({'error': 'Query is required'}), 400

        # Load the model
        vectorizer, train_names, train_vectors = load_model()

        # Find the best match
        best_match = find_best_match(query, vectorizer, train_vectors, train_names)
        
        return jsonify({'best_match': best_match})
    else:
        # Render search page if the method is GET
        return render_template('search.html')

# Route for displaying search results
@app.route('/search_results', methods=['POST'])
def search_results():
    museum_name = request.form.get('museum_name')
    user_type = request.form.get('user_type')

    if not museum_name or not user_type:
        return render_template('error.html', message="Please provide both museum name and user type.")

    # Use the search function to refine the museum name
    vectorizer, train_names, train_vectors = load_model()
    refined_museum_name = find_best_match(museum_name, vectorizer, train_vectors, train_names)

    # Fetch museum details based on the refined name
    museum_details = fetch_museum_data_by_name_with_prices(refined_museum_name, user_type)
    if not museum_details:
        return render_template('error.html', message="Museum or ticket price not found.")
    
    # Render the museum details page
    return render_template('museum_details.html', museum_details=museum_details)

@app.route('/get_ticket_prices', methods=['POST'])
def get_ticket_prices():
    """Fetch and display ticket prices for a selected museum and user type."""
    museum_name = request.form.get('museum_name')
    user_type = request.form.get('user_type')

    if not museum_name or not user_type:
        return jsonify({'error': 'Missing form data. Please make sure all fields are filled.'}), 400

    price_info = fetch_ticket_prices_by_type(museum_name, user_type)
    if price_info:
        return jsonify(price_info)
    else:
        return jsonify({'error': 'Ticket prices not found for the selected museum and user type.'}), 404

@app.route('/book_ticket/<museum_name>', methods=['GET'])
def book_ticket_form(museum_name):
    """Render the ticket booking form."""
    return render_template('book_ticket.html', museum_name=museum_name)

@app.route('/book_ticket', methods=['GET', 'POST'])
def book_ticket():
    if request.method == 'POST':
        # Get form data
        museum_name = request.form.get('museum_name')
        user_name = request.form.get('user_name')
        adult_tickets = request.form.get('adult_tickets')
        children_tickets = request.form.get('children_tickets')
        photography_tickets = request.form.get('photography_tickets')

        # Validate and process the form data
        try:
            adult_tickets = int(adult_tickets)
            children_tickets = int(children_tickets)
            photography_tickets = int(photography_tickets)

            if adult_tickets < 0 or children_tickets < 0 or photography_tickets < 0:
                flash("Ticket quantities cannot be negative.", "error")
                return redirect(url_for('book_ticket'))

            # Generate a ticket ID (This can be any unique identifier logic you want)
            ticket_id = random.randint(0, 9999)

            # Prepare booking details
            booking_details = {
                'ticket_id': ticket_id,
                'user_name': user_name,
                'adult_tickets': adult_tickets,
                'children_tickets': children_tickets,
                'photography_tickets': photography_tickets,
                'booking_date': datetime.now().strftime('%Y-%m-%d'),
                'booking_time': datetime.now().strftime('%H:%M:%S')
            }

            # Store booking details in the database
            store_booking_in_db(booking_details)

        except ValueError:
            flash("Invalid input. Please enter valid numbers for ticket quantities.", "error")
            return redirect(url_for('book_ticket'))

        # Redirect to the next page for entering the visit date and time
        flash(f"Ticket ID {ticket_id} created successfully!", "success")
        return redirect(url_for('enter_date', museum_name=museum_name, user_name=user_name))

    return render_template('book_ticket.html')

def generate_ticket_id():
    """Generate a unique ticket ID by incrementing the last ticket ID."""
    last_ticket_id = max([booking['ticket_id'] for user in user_bookings.values() for museum in user.values() for booking in museum], default=0)
    return last_ticket_id + 1

@app.route('/enter_date', methods=['GET', 'POST'])
def enter_date():
    """Render the page for entering the booking date and time."""
    if request.method == 'POST':
        # Get the submitted date and time
        booking_year = request.form.get('booking_year')
        booking_month = request.form.get('booking_month')
        booking_day = request.form.get('booking_day')
        booking_hour = request.form.get('booking_hour')
        booking_minute = request.form.get('booking_minute')
        booking_period = request.form.get('booking_period')

        if not (booking_year and booking_month and booking_day and booking_hour and booking_minute and booking_period):
            flash("Please enter a valid date and time for your booking.", "error")
            return redirect(url_for('enter_date'))

        # Combine the input values into a single datetime string (e.g., "YYYY-MM-DD HH:MM AM/PM")
        booking_date_str = f"{booking_year}-{booking_month.zfill(2)}-{booking_day.zfill(2)}"
        booking_time_str = f"{booking_hour}:{booking_minute.zfill(2)} {booking_period}"

        # Validate if the combined datetime string is a valid datetime object
        try:
            booking_datetime = datetime.strptime(f"{booking_date_str} {booking_time_str}", "%Y-%m-%d %I:%M %p")
        except ValueError:
            flash("Invalid date or time format. Please check your inputs.", "error")
            return redirect(url_for('enter_date'))

        # Generate a unique ticket ID or fetch the last assigned ticket ID
        ticket_id = generate_ticket_id()  # A function to generate unique ticket IDs

        booking_details = session.get('booking_details', {})
        museum_name = booking_details.get('museum_name', 'Unknown')
        museum_data = fetch_museum_data(museum_name)
        opening_hours = museum_data.get('opening_hours', 'Not available') if museum_data else "Not available"
        holidays = museum_data.get('holidays', 'Not available') if museum_data else "Not available"
        required_time = museum_data.get('required_time', 'Not available') if museum_data else "Not available"

        # Check if the museum is open at the specified date and time
        is_open, message = is_museum_open(museum_name, booking_date_str, booking_time_str)
        if not is_open:
            flash(
                f"{message} The museum's opening hours are: {opening_hours}. Holidays: {holidays}.", 
                "error"
            )
            return redirect(url_for('enter_date'))

        # Update the booking details with the date, time, and generated ticket ID
        booking_details.update({
            'booking_date': booking_date_str, 
            'booking_time': booking_time_str,
            'ticket_id': ticket_id
        })

        user_name = booking_details.get('user_name')
        
        # Store the booking under the user and museum in user_bookings
        user_bookings.setdefault(user_name, {}).setdefault(museum_name, []).append(booking_details)

        flash(f"Successfully booked tickets for {museum_name} on {booking_date_str} at {booking_time_str}. Ticket ID: {ticket_id}", "success")
        return redirect(url_for('my_bookings', user_name=user_name))

    # For the GET request, retrieve the museum data and pass it to the template
    booking_details = session.get('booking_details', {})
    museum_name = booking_details.get('museum_name', 'Unknown')
    museum_data = fetch_museum_data(museum_name)

    opening_hours = museum_data.get('opening_hours', 'Not available') if museum_data else "Not available"
    holidays = museum_data.get('holidays', 'Not available') if museum_data else "Not available"
    required_time = museum_data.get('required_time', 'Not available') if museum_data else "Not available"

    return render_template('enter_date.html', opening_hours=opening_hours, holidays=holidays, required_time=required_time)

@app.route('/my_bookings')
def my_bookings():
    """Display the user's bookings."""
    user_name = request.args.get('user_name')
    if user_name in user_bookings:
        bookings = user_bookings[user_name]
        return render_template('my_bookings.html', user_name=user_name, bookings=bookings)
    else:
        return render_template('error.html', message="No bookings found for this user.")

@app.route('/booking_management', methods=['GET'])
def booking_management():
    """Render the booking management page with options to change time slot, change date slot, and cancel booking."""
    return render_template('booking_management.html')

@app.route('/change_time', methods=['GET', 'POST'])
def change_time():
    """Render the time change form and handle the submission."""
    ticket_id = request.args.get('ticket_id')  # Get the ticket ID from the URL
    
    if request.method == 'POST':
        new_time = request.form.get('new_time')
        if not ticket_id or not new_time:
            flash("Please enter a valid ticket ID and time.", "error")
            return redirect(url_for('change_time', ticket_id=ticket_id))

        conn = sqlite3.connect('bookings.db')
        cursor = conn.cursor()

        # Find the booking by ticket ID and update the time
        cursor.execute('''SELECT * FROM ticket_booking WHERE id = ?''', (ticket_id,))
        booking = cursor.fetchone()

        if booking:
            cursor.execute('''UPDATE ticket_booking SET visit_time = ? WHERE id = ?''', (new_time, ticket_id))
            conn.commit()
            conn.close()
            flash(f"Successfully changed time to {new_time} for Ticket ID: {ticket_id}", "success")
            return redirect(url_for('my_bookings', user_name=session.get('user_name')))
        else:
            conn.close()
            flash("Booking not found.", "error")
            return redirect(url_for('change_time', ticket_id=ticket_id))

    return render_template('change_time.html', ticket_id=ticket_id)

@app.route('/change_date', methods=['GET', 'POST'])
def change_date():
    """Render the date change form and handle the submission."""
    ticket_id = request.args.get('ticket_id')  # Get the ticket ID from the URL
    
    if request.method == 'POST':
        new_date = request.form.get('new_date')
        if not ticket_id or not new_date:
            flash("Please enter a valid ticket ID and date.", "error")
            return redirect(url_for('change_date', ticket_id=ticket_id))

        conn = sqlite3.connect('bookings.db')
        cursor = conn.cursor()

        # Find the booking by ticket ID and update the date
        cursor.execute('''SELECT * FROM ticket_booking WHERE id = ?''', (ticket_id,))
        booking = cursor.fetchone()

        if booking:
            cursor.execute('''UPDATE ticket_booking SET visit_date = ? WHERE id = ?''', (new_date, ticket_id))
            conn.commit()
            conn.close()
            flash(f"Successfully changed date to {new_date} for Ticket ID: {ticket_id} with the same time slot", "success")
            return redirect(url_for('my_bookings', user_name=session.get('user_name')))
        else:
            conn.close()
            flash("Booking not found.", "error")
            return redirect(url_for('change_date', ticket_id=ticket_id))

    return render_template('change_date.html', ticket_id=ticket_id)

@app.route('/cancel_booking', methods=['GET', 'POST'])
def cancel_booking():
    """Render the booking cancellation form and handle the submission."""
    if request.method == 'POST':
        ticket_id = request.form.get('ticket_id')
        if not ticket_id:
            flash("Please enter a valid ticket ID.", "error")
            return redirect(url_for('cancel_booking'))

        conn = sqlite3.connect('bookings.db')
        cursor = conn.cursor()

        # Find the booking by ticket ID
        cursor.execute('''SELECT * FROM ticket_booking WHERE id = ?''', (ticket_id,))
        booking = cursor.fetchone()

        if booking:
            booking_datetime = datetime.strptime(f"{booking[6]} {booking[7]}", "%Y-%m-%d %H:%M")  # Assuming visit_date is in index 6 and visit_time in index 7
            current_datetime = datetime.now()
            time_difference = booking_datetime - current_datetime

            if time_difference < timedelta(hours=24):
                flash("Only 50% will be refunded as the cancellation is within 24 hours of the booking time.", "warning")
                return render_template('confirm_cancellation.html', ticket_id=ticket_id, partial_refund=True)
            else:
                flash("Full refund will be provided.", "success")
                return render_template('confirm_cancellation.html', ticket_id=ticket_id, partial_refund=False)
        else:
            conn.close()
            flash("Booking not found.", "error")
            return redirect(url_for('cancel_booking'))

    return render_template('cancel_booking.html')

@app.route('/confirm_cancellation', methods=['POST'])
def confirm_cancellation():
    """Handle the final confirmation of the booking cancellation."""
    ticket_id = request.form.get('ticket_id')
    if not ticket_id:
        return render_template('error.html', message="Invalid ticket ID.")

    conn = sqlite3.connect('bookings.db')
    cursor = conn.cursor()

    # Find the booking by ticket ID and remove it
    cursor.execute('''DELETE FROM ticket_booking WHERE id = ?''', (ticket_id,))
    conn.commit()
    conn.close()

    flash(f"Successfully canceled booking for Ticket ID: {ticket_id}. Amount will be refunded in 3 working days.", "success")
    return redirect(url_for('my_bookings'))
    
if __name__ == '__main__':
    app.run(debug=True)